# Rocket Group / Forward Momentum

An editable 15-second launch introduction: 1920 × 1080, 16:9, 60 fps (900 frames), H.264 MP4, original stereo soundtrack.

## Open and preview

Requirements: Node.js 22+, FFmpeg and Chrome/Chromium. The project bundles its fonts, original logo assets, GSAP browser runtime and audio, so preview needs no external asset requests.

```bash
cd rocket-launch
node scripts/serve.mjs
```

Open the address printed by the server in your own browser. `preview.html` provides playback, an exact timeline scrubber and sound controls. It loads the editable HTML composition directly. Stop the server with Ctrl+C. Preview also works by opening `preview.html` locally in browsers that allow same-folder iframe access; the local server is recommended.

## Edit

- `index.html`: named scene elements, editable text, UI controls, cursors, official logo assets.
- `design.css`: layout, typography, palette, selection frames, panels, rulers and guides.
- `config.js`: palette, primary text and motion parameters. Scene entrances are explicitly timed in `motion.js`; if retiming, adjust their corresponding timestamps there as well.
- `motion.js`: labeled GSAP timeline, keyframes, easing, cursor paths, scene transitions, shallow camera movement. All times are in seconds, seek-safe and deterministic.
- `assets/`: unchanged supplied logo PNGs, local fonts, GSAP runtime and third-party notices.
- `audio/`: separate music and SFX stems, final mix, original synthesis source and license metadata.
- `DESIGN.md`, `SCRIPT.md`, `STORYBOARD.md`, `BRAND-RESEARCH.md`: creative direction and evidence.

The project is editable HTML/CSS/JavaScript, not an After Effects or Premiere project. The final MP4 is the flattened delivery; the files above are the editable master.

## Install, validate and render

```bash
npm ci
npm run check
npm run render
```

The CLI is pinned to HyperFrames 0.8.167. It can use system Chrome/Chromium; if autodetection fails, set `HYPERFRAMES_BROWSER_PATH` to your browser executable. The final render defaults to `renders/rocket-group-launch.mp4` at 60 fps and high quality. For a cloud account with an unwritable default npm cache, prefix npm commands with `npm_config_cache=/workspace/.cache/npm` or another writable cache directory.

Optional HyperFrames Studio timeline:

```bash
npm run studio
```

Use the project URL printed by HyperFrames. Stop the background Studio with `npx hyperframes preview --stop`. In this cloud workspace, prefix both commands with `XDG_STATE_HOME=/workspace/.cache/state` because the default home state directory is not writable.

Visual review frames can be regenerated while the local preview server is running:

```bash
npm run review
```

To regenerate the original audio (requires Python, NumPy and SciPy):

```bash
python3 audio/synthesize.py
```

## Brand verification and limitations

The live website could not be accessed: the managed proxy returned CONNECT 403. No website screenshot, business offering, site headline or site font was fabricated. This film uses the explicitly authorized brand-introduction fallback: the original Rocket identity, “Discover Rocket Group” and `rocketgroup.asia`, shown within clearly editorial motion-design overlays.

Verified logo colors: black `#000000`, arrow yellow `#F0C400`. Paper `#F5F4F0` and charcoal `#161616` are creative supporting neutrals. Manrope and IBM Plex Mono are disclosed OFL substitutes, not verified site fonts. The logo files are unchanged. See `BRAND-RESEARCH.md` for evidence.

The requested `motion-system` and `higgsfield-saas` skills were unavailable. Production used the available HyperFrames and GSAP skills, with an original procedurally composed soundtrack. There is no generated product interface or implied SaaS functionality.

## Rights and notices

The supplied logo assets retain their original ownership. Manrope and IBM Plex Mono are SIL Open Font License 1.1; notices are included under `assets/`. GSAP's standard no-charge license and source are linked in `assets/GSAP-NOTICE.md`. HyperFrames is Apache-2.0. The original music and SFX are provided under CC0 as recorded in `audio/metadata.json`.

## Delivery

- `renders/rocket-group-launch.mp4`: final film.
- `renders/thumbnail.png`: final-frame thumbnail.
- `review/validation.json`: measured delivery properties and review outcome.

Original repository source and existing output videos were preserved. This work is self-contained in `rocket-launch/`.
