# Storyboard
Format: 1920x1080, 60fps, 15 seconds. Original music, no VO.

| Beat | Time | Visual / camera | Interaction / transition |
|---|---|---|---|
| Identity | 0–2 | Light large selection-artboard with original wordmark; arrow accents, shallow push | Single cursor selects the logo, fine frame builds; left push at 1.85 |
| Discover | 2–5.5 | Oversized two-line black title on yellow; small original mark with white tile; camera drifts closer | Cursor points to title and frame snaps; horizontal handoff at 5.25 |
| Workspace | 5.5–10.5 | Dark creative editor with light official-logo artboard; rulers, property panel, foreground pointer; shallow orbit resolves toward URL | Properties reveal; cursor adjusts position, URL receives selection; right-to-left handoff at 10.25 |
| Resolution | 10.5–15 | Warm-white stage with original wordmark, restrained yellow arrow, large URL and Discover Rocket Group | Cursor resolves to arrow; entrance ends before 12.5, stable hold thereafter |

## Asset audit
mark.png: original supplied PNG, used within small identity tiles.
wordmark.png: original supplied PNG, primary wide logo.
Fonts: Manrope + IBM Plex Mono, OFL, creative substitutes.
Website: inaccessible, no screenshot used.
Audio: original procedural composition, separate music/SFX stems and synthesis source.
