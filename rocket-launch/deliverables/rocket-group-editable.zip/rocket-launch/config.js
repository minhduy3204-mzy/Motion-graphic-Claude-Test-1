/* Editable brand, copy and motion parameters. All timing is in seconds. */
window.ROCKET_CONFIG = {
  width: 1920, height: 1080, fps: 60, duration: 15,
  colors: { black: '#000000', yellow: '#F0C400', paper: '#F5F4F0', workspace: '#161616' },
  copy: { discover: 'Discover', name: 'Rocket Group', url: 'rocketgroup.asia', cta: 'Discover Rocket Group' },
  beats: { identity: 0, discover: 2, workspace: 5.5, resolution: 10.5, hold: 12.5 },
  motion: { transition: 0.60, entrance: 0.55, cameraDrift: 0.025, ease: 'power3.out' }
};
