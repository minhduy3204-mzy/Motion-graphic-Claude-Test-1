# Rocket Group — brand research and production limits

Research date: 17 October 2026.

## Verified source assets

The supplied checkout contains the original reference artwork at `../mark.png` and `../wordmark.png`. The project uses copies in `assets/` and preserves the original artwork and proportions.

| Asset | Dimensions | Observed treatment |
| --- | --- | --- |
| `mark.png` | 186 × 200 px | Transparent PNG; geometric black R with a yellow right-pointing arrow entering from the left. |
| `wordmark.png` | 1998 × 340 px | Transparent PNG; original black wordmark with yellow arrow detail. |

Pixel inspection with Pillow, counting RGB values only where alpha exceeds 200, found these dominant exact opaque colors:

| Color | HEX | Mark pixel count | Wordmark pixel count |
| --- | --- | --- | --- |
| Black | `#000000` | 10,679 | 222,047 |
| Yellow | `#F0C400` | 396 | 1,734 |

Nearby yellow RGB values occur on antialiased edges. These counts verify the supplied assets' colors, not the current live website palette. Light neutral backgrounds and supporting gray UI strokes are production choices used for legibility. The small mark is unsuitable for substantial raster enlargement; the higher-resolution original wordmark is preferred for prominent logo placement.

## Website access and unverified information

The requested source is <https://rocketgroup.asia/>. An ordinary HTTPS request through the inherited managed proxy failed on 17 October 2026 with:

```text
curl: (56) CONNECT tunnel failed, response 403
HTTP/1.1 403 Forbidden
server: envoy
```

The runtime reported restricted networking with the package-manager preset and no custom allowed host for `rocketgroup.asia`; the observed network policy state was `unknown`. The concrete access result is the failed HTTPS request above. No proxy bypass, alternate route, trust weakening, or network configuration change was used.

No website HTML, screenshot, font declaration, service description, headline, or CTA could therefore be independently verified. The checkout contains no website capture or application source; its README supplies only the repository title. Existing video renders are not treated as evidence of live website content.

The user explicitly authorized a brand-led fallback when official website content could not be accessed. Accordingly, the video uses only the supplied identity and the approved copy:

- **Rocket Group**
- **Discover Rocket Group**
- **rocketgroup.asia**

No actual website page, service offering, dashboard, testimonial, statistic, or unsupported business claim is depicted. Cursors, selection frames, rulers, guides, and property panels are editorial motion-design overlays around the identity, not representations of a Rocket Group software product or website interface.

## Disclosed typography substitutions

The live website fonts are unknown. These fonts are deliberate creative substitutes, not claimed brand fonts:

- **Manrope variable**, from `@fontsource-variable/manrope` version `5.3.0`, for bold headlines and readable supporting text.
- **IBM Plex Mono**, from `@fontsource/ibm-plex-mono` version `5.3.0`, for compact UI labels, rulers, and property values.

Both installed Fontsource packages include SIL Open Font License 1.1 notices in their `LICENSE` files. Preserve those notices with redistributed font assets. The official wordmark remains original artwork rather than reconstructed lettering.

## Skill availability and implementation

The requested **motion-system** and **higgsfield-saas** skills were unavailable in this session's skill catalog. Their private instructions and capabilities could not be read or asserted. The user authorized continuing with available production tools in this case.

The implementation uses the available **HyperFrames** composition, website-video, CLI, and **GSAP** guidance. An editable HTML/CSS/SVG composition and named GSAP timeline implement the motion direction: smooth acceleration and settling, cursor selections, masked typography reveals, arrow-led continuity, restrained parallax, and a stable final logo/URL hold.

Colors, typography, timings, scene elements, camera transforms, and audio remain accessible in the source project. The output is a 15-second, 16:9 brand introduction; it does not claim to reproduce the inaccessible live website.
