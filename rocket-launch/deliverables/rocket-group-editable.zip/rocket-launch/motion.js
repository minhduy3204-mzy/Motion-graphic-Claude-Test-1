/* All motion stays editable and deterministically seekable in GSAP. */
window.RocketLaunch = {
  build() {
    const C = window.ROCKET_CONFIG;
    const root = document.documentElement;
    for (const [name,color] of Object.entries(C.colors)) root.style.setProperty('--'+name,color);
    document.querySelector('#discover-line').textContent=C.copy.discover;
    document.querySelector('#rocket-line').textContent=C.copy.name;
    document.querySelector('#workspace-url').textContent=C.copy.url;
    document.querySelector('#final-url').textContent=C.copy.url;
    const tl=gsap.timeline({paused:true,defaults:{duration:C.motion.entrance,ease:C.motion.ease}});
    tl.addLabel('01 / Identity',0).addLabel('02 / Discover',2).addLabel('03 / Workspace',5.5).addLabel('04 / Resolution',10.5).addLabel('Final hold',12.5);
    // Scene 01. Correct resting layout lives in CSS; entrances travel into it.
    tl.from('.identity-top',{opacity:0,y:-16,duration:.45,ease:'sine.out'},.12);
    tl.from('.identity-bottom',{opacity:0,y:18,duration:.5,ease:'power2.out'},.2);
    tl.from('.identity-artboard',{scale:.97,opacity:0,duration:.65,ease:'power3.out'},.12);
    tl.from('#identity-wordmark',{clipPath:'inset(0% 100% 0% 0%)',x:-28,duration:.78,ease:'power4.out'},.21);
    tl.from('.identity-badge',{opacity:0,y:8,duration:.4,ease:'sine.out'},.35);
    tl.from('.identity-ruler',{scaleX:0,transformOrigin:'left center',duration:.65,ease:'power2.out'},.22);
    tl.from('.coordinate-tag',{opacity:0,x:-20,duration:.35,ease:'power1.out'},.65);
    tl.from('#opening-arrow',{x:-270,opacity:0,duration:.55,ease:'power4.out'},.1);
    tl.to('#opening-arrow',{x:1590,duration:1.3,ease:'power3.inOut'},.55);
    tl.from('#cursor-identity',{x:220,y:165,opacity:0,duration:.60,ease:'power3.out'},.48);
    tl.from('#identity-selection .edge-top, #identity-selection .edge-bottom',{scaleX:0,transformOrigin:'left',duration:.35,ease:'expo.out'},1.02);
    tl.from('#identity-selection .edge-left, #identity-selection .edge-right',{scaleY:0,transformOrigin:'top',duration:.35,ease:'power2.out'},1.02);
    tl.from('#identity-selection .handle',{scale:0,duration:.3,stagger:.025,ease:'back.out(1.2)'},1.04);
    tl.from('.dimension-tag',{opacity:0,y:7,duration:.3,ease:'sine.out'},1.15);
    tl.fromTo('#click-identity',{scale:.2,opacity:0},{scale:1.2,opacity:.75,duration:.2,ease:'power2.out'},1.0);
    tl.to('#click-identity',{scale:1.6,opacity:0,duration:.2,ease:'sine.out'},1.2);
    tl.to('.identity-camera',{scale:1.018,x:-12,duration:1.8,ease:'sine.inOut'},.2);
    // Transition 1: the new yellow scene pushes the selected artboard left.
    const push=(oldScene,newScene,time,duration=.6)=>{
      tl.to(oldScene,{x:-1920,duration,ease:'power3.inOut'},time);
      tl.fromTo(newScene,{x:1920,opacity:1},{x:0,duration,ease:'power3.inOut'},time);
    };
    push('#scene-identity','#scene-discover',1.8,.62);
    // Scene 02.
    tl.from('.discover-top .brand-tile',{scale:.8,rotation:-4,opacity:0,duration:.6,ease:'power3.out'},2.02);
    tl.from('.discover-top>.mono',{y:-18,opacity:0,duration:.5,ease:'sine.out'},2.15);
    tl.from('.type-label',{x:-24,opacity:0,duration:.5,ease:'power2.out'},2.2);
    tl.from('#discover-line',{yPercent:110,duration:.7,ease:'power4.out'},2.15);
    tl.from('#rocket-line',{yPercent:110,duration:.8,ease:'power3.out'},2.32);
    tl.from('.discover-bottom',{y:18,opacity:0,duration:.5,ease:'sine.out'},2.55);
    tl.from('#cursor-type',{x:230,y:150,opacity:0,duration:.8,ease:'power3.out'},2.75);
    tl.from('#title-selection .edge-top, #title-selection .edge-bottom',{scaleX:0,transformOrigin:'left',duration:.42,ease:'expo.out'},3.43);
    tl.from('#title-selection .edge-left, #title-selection .edge-right',{scaleY:0,transformOrigin:'top',duration:.35,ease:'power2.out'},3.43);
    tl.from('#title-selection .handle',{scale:0,duration:.3,stagger:.03,ease:'back.out(1.1)'},3.45);
    tl.from('.type-size',{opacity:0,y:10,duration:.4,ease:'power2.out'},3.6);
    tl.fromTo('#click-type',{scale:.15,opacity:0},{scale:1.1,opacity:.65,duration:.18,ease:'power2.out'},3.43);
    tl.to('#click-type',{scale:1.6,opacity:0,duration:.18,ease:'sine.out'},3.61);
    tl.to('.discover-camera',{scale:1.035,x:7,duration:2.5,ease:'sine.inOut'},2.65);
    tl.to('#cursor-type',{x:45,y:20,duration:.6,ease:'power2.inOut'},4.15);
    // Transition 2: a continuous horizontal canvas handoff.
    push('#scene-discover','#scene-workspace',5.2,.6);
    // Scene 03.
    tl.from('.workspace-camera',{scale:.94,rotationY:-2.4,rotationZ:-.7,y:28,duration:1.1,ease:'power3.out'},5.4);
    tl.from('.editor-header',{opacity:0,y:-16,duration:.45,ease:'sine.out'},5.5);
    tl.from('.tools .tool',{opacity:0,x:-15,duration:.4,stagger:.05,ease:'power2.out'},5.55);
    tl.from('.canvas-top-ruler',{scaleX:0,transformOrigin:'left',duration:.65,ease:'power2.out'},5.6);
    tl.from('.canvas-left-ruler',{scaleY:0,transformOrigin:'top',duration:.65,ease:'power2.out'},5.6);
    tl.from('.artboard-label',{opacity:0,y:10,duration:.4,ease:'sine.out'},5.65);
    tl.from('#workspace-artboard',{scale:.96,opacity:0,y:20,duration:.7,ease:'power4.out'},5.6);
    tl.from('.artboard-heading',{opacity:0,y:8,duration:.4,ease:'sine.out'},5.75);
    tl.from('#workspace-wordmark',{clipPath:'inset(0% 100% 0% 0%)',duration:.7,ease:'power3.out'},5.7);
    tl.from('.workspace-logo-frame .selection-edge',{opacity:0,duration:.35,ease:'power2.out'},6.25);
    tl.from('.workspace-logo-frame .handle',{scale:0,stagger:.03,duration:.25,ease:'back.out(1.2)'},6.28);
    tl.from('.artboard-url-row',{opacity:0,y:18,duration:.6,ease:'power2.out'},5.9);
    tl.from('.properties',{x:30,opacity:0,duration:.55,ease:'power3.out'},5.55);
    tl.from('.property-tabs',{opacity:0,y:10,duration:.4,ease:'sine.out'},5.75);
    tl.from('.property-section',{opacity:0,y:16,duration:.5,stagger:.12,ease:'power2.out'},5.85);
    tl.from('.layer-indicator',{opacity:0,duration:.4,ease:'sine.out'},6.2);
    tl.from('.editor-footer',{opacity:0,y:12,duration:.45,ease:'power2.out'},5.75);
    tl.from('.canvas-guide',{opacity:0,duration:.4,ease:'sine.out'},6.1);
    tl.from('.canvas-zoom',{opacity:0,duration:.3,ease:'power2.out'},6.2);
    tl.from('#cursor-workspace',{x:180,y:130,opacity:0,duration:.65,ease:'power3.out'},6.15);
    tl.to('#cursor-workspace',{x:30,y:0,duration:.5,ease:'power2.inOut'},6.85);
    tl.to('#scale-field',{backgroundColor:'#393622',outlineColor:'#F0C400',outlineWidth:1,outlineStyle:'solid',duration:.25,ease:'sine.out'},7.22);
    tl.fromTo('#click-workspace',{scale:.2,opacity:0},{scale:1.1,opacity:.75,duration:.18,ease:'power2.out'},7.24);
    tl.to('#click-workspace',{scale:1.6,opacity:0,duration:.2,ease:'sine.out'},7.42);
    tl.to('#workspace-artboard',{scale:1.018,duration:.65,ease:'power3.inOut'},7.24);
    tl.to('.timeline-playhead',{x:310,duration:4.1,ease:'none'},6.0);
    tl.to('#cursor-workspace',{x:-732,y:263,duration:.9,ease:'power3.inOut'},7.8);
    tl.from('.url-underline',{scaleX:0,duration:.6,ease:'power4.out'},8.55);
    tl.to('.workspace-camera',{scale:1.035,x:-14,y:-3,rotationY:0.7,duration:2.05,ease:'sine.inOut'},8.05);
    // Transition 3: selected canvas gives way to the final light brand stage.
    push('#scene-workspace','#scene-resolution',10.2,.65);
    // Scene 04. All entrances finish by 12.5; final hold is intentional.
    tl.from('.resolution-top',{opacity:0,y:-18,duration:.5,ease:'sine.out'},10.55);
    tl.from('.resolution-bottom',{opacity:0,y:15,duration:.5,ease:'power2.out'},10.65);
    tl.from('.final-left-guide, .final-right-guide',{scaleY:0,transformOrigin:'center',duration:.85,ease:'power2.out'},10.65);
    tl.from('.outro-eyebrow',{y:20,opacity:0,duration:.65,ease:'power2.out'},10.8);
    tl.from('#final-wordmark',{clipPath:'inset(0% 100% 0% 0%)',x:-25,duration:.9,ease:'power4.out'},10.85);
    tl.from('.final-rule',{scaleX:0,duration:.75,ease:'power3.out'},11.1);
    tl.from('#final-url',{y:28,opacity:0,duration:.65,ease:'power3.out'},11.25);
    tl.from('.final-arrow-disc',{scale:0,rotation:-32,duration:.6,ease:'back.out(1.15)'},11.4);
    tl.from('.final-arrow',{x:-12,opacity:0,duration:.4,ease:'expo.out'},11.65);
    tl.from('.resolution-camera',{scale:.985,y:12,duration:1.4,ease:'sine.out'},10.8);
    return tl;
  }
};
