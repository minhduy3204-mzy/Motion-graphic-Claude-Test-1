# Rocket Group — Forward Momentum audio

`soundtrack.wav` is the ready-to-use stereo mix. `music.wav` and `sfx.wav`
are separate, aligned stems with the same start time and master gain.

- Duration: **15.000 seconds / 720,000 samples**.
- Format: stereo PCM16 WAV, 48,000 Hz.
- Tempo / key: 120 BPM / F major.
- Scene accents: 0, 2, 5.5, 10.5, and 12.5 seconds.
- Final F-major cadence: 12.5 seconds, followed by a clean ambient tail.
- Original synthesized music and SFX; no external recordings or samples.

All assets and the synthesis script are released under **CC0-1.0**:
<https://creativecommons.org/publicdomain/zero/1.0/>.

## Editing / rebuilding

Run `python audio/synthesize.py` from the project root, or
`python synthesize.py` from this directory. Python 3, NumPy, and SciPy are
required. The deterministic script exposes note voicings, melodic events,
percussion levels, cursor sounds, swishes, stereo placement, and master gain.
It regenerates all three WAV files and `metadata.json`.

Keep both stems at unity gain to reconstruct the supplied mix. Independent
16-bit quantization dither produces only negligible sample-level differences.

## Validation

FFprobe confirmed 15.000000 seconds, 48 kHz, stereo, PCM16.
FFmpeg EBU R128 / true-peak analysis of the supplied mix reported:

- Integrated loudness: **−15.52 LUFS**.
- True peak: **−1.60 dBTP**.
- Loudness range: **2.80 LU**.
- Clipped samples: **0**.

The start and last sample are zero; a 650 ms final fade prevents an abrupt cutoff.
