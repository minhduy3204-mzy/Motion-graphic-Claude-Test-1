#!/usr/bin/env python3
"""Original Rocket Group launch score and UI sound design.

Rebuild with: python audio/synthesize.py (requires numpy and scipy).
All sounds are synthesized here; no samples or third-party music are used.
Copyright waived under CC0-1.0 for these generated audio assets and this script.
"""
from pathlib import Path
import json
import math
import numpy as np
from scipy import signal
from scipy.io import wavfile

OUT = Path(__file__).resolve().parent
SR = 48000
DURATION = 15.0
N = int(SR * DURATION)
RNG = np.random.default_rng(240417)
music = np.zeros((N, 2), np.float64)
wet_bus = np.zeros_like(music)
sfx = np.zeros_like(music)


def midi(n):
    return 440.0 * 2 ** ((n - 69) / 12)


def seconds(duration):
    return np.arange(round(duration * SR)) / SR


def filtered(x, hz, kind="lowpass", order=2):
    return signal.sosfilt(signal.butter(order, hz, btype=kind, fs=SR, output="sos"), x)


def add(bus, x, when, gain=1.0, pan=0.0):
    start = round(when * SR)
    if start >= N:
        return
    x = x[:N-start]
    if x.ndim == 1:
        # Equal-power panning; deliberate sound-source placement remains editable.
        angle = (pan + 1) * np.pi / 4
        x = np.column_stack((x * np.cos(angle), x * np.sin(angle)))
    bus[start:start+len(x)] += x * gain


def fades(length, attack=0.005, release=0.03):
    env = np.ones(length)
    a, r = min(round(attack * SR), length), min(round(release * SR), length)
    if a:
        env[:a] *= np.sin(np.linspace(0, np.pi/2, a)) ** 2
    if r:
        env[-r:] *= np.cos(np.linspace(0, np.pi/2, r)) ** 2
    return env


def pluck(note, duration=1.15, velocity=1.0, mellow=1.0):
    t = seconds(duration)
    f = midi(note)
    # Decaying partials give the warm attack of a soft electric-piano/pluck hybrid.
    y = np.zeros_like(t)
    for h in range(1, 8):
        amp = (0.72 if h == 1 else 0.34 / h**1.45) * np.exp(-t * (2.9 + h * mellow))
        detune = 1.0005 if h % 2 else 0.9994
        y += amp * np.sin(2*np.pi*f*h*detune*t + 0.07*h)
    y += 0.12*np.sin(2*np.pi*f*2.001*t) * np.exp(-t*8)
    return np.tanh(y*1.15) * fades(len(t), 0.004, 0.07) * velocity


def pad(notes, duration, velocity=1):
    t = seconds(duration)
    y = np.zeros((len(t), 2))
    for i, note in enumerate(notes):
        f = midi(note)
        for side, cents in enumerate((-4, 4)):
            ff = f * 2**(cents/1200)
            tone = np.sin(2*np.pi*ff*t + i*.4)
            tone += .18*np.sin(2*np.pi*ff*2*t + .2)
            tone += .055*np.sin(2*np.pi*ff*3*t + .5)
            y[:, side] += tone
    env = fades(len(t), .32, min(1.1, duration*.35))
    env *= .86 + .14*np.sin(2*np.pi*.16*t)
    return y * env[:, None] * velocity / len(notes)


def bass(note, duration=.43):
    t = seconds(duration)
    f = midi(note)
    y = np.sin(2*np.pi*f*t) + .20*np.sin(2*np.pi*f*2*t) + .07*np.sin(2*np.pi*f*3*t)
    env = (1 - np.exp(-t*170)) * np.exp(-t*4.2) * fades(len(t), .008, .055)
    return np.tanh(y*.95) * env


def kick():
    t = seconds(.39)
    freq = 48 + 76*np.exp(-t*35)
    phase = 2*np.pi*np.cumsum(freq)/SR
    body = np.sin(phase)*np.exp(-t*13)
    transient = filtered(RNG.normal(0, 1, len(t)), 2500) * np.exp(-t*220)*.14
    return np.tanh((body+transient)*1.2)*fades(len(t), .002, .02)


def clap():
    t = seconds(.22)
    noise = filtered(RNG.normal(size=len(t)), [800, 7600], "bandpass")
    env = sum(np.exp(-np.maximum(t-d, 0)*80)*(t>=d) for d in (0, .009, .021))
    env += .34*np.exp(-t*22)
    return noise*env*.22*fades(len(t), .001, .035)


def hat(open_hat=False):
    duration = .19 if open_hat else .065
    t = seconds(duration)
    noise = filtered(RNG.normal(size=len(t)), [5800, 13000], "bandpass")
    return noise*np.exp(-t*(27 if open_hat else 72))*fades(len(t), .001, .025)


# F-major progression: warm, optimistic, restrained. Editable note voicings.
CHORDS = [
    (0.0, [53, 60, 64, 69], 29),     # Fmaj7
    (2.0, [50, 57, 60, 65], 26),     # Dm7
    (4.0, [46, 53, 57, 62], 22),     # Bbmaj7
    (6.0, [48, 55, 62, 64], 24),     # Cadd9
    (8.0, [50, 57, 60, 65], 26),     # Dm7
    (10.0, [46, 53, 57, 62], 22),    # Bbmaj7
    (12.0, [48, 55, 62, 64], 24),    # Cadd9, short lead-in
    (12.5, [53, 60, 64, 69, 72], 29) # final Fmaj7 / logo resolve
]

for i, (start, notes, root) in enumerate(CHORDS):
    next_time = CHORDS[i+1][0] if i+1 < len(CHORDS) else 15
    span = next_time-start
    add(wet_bus, pad(notes, min(span+1.2, 15-start), .72), start, .19)
    # Brushed chord attack. Each upper note has a slight temporal spread.
    for j, note in enumerate(notes):
        add(wet_bus, pluck(note+12, 2.0, .65), start+j*.017, .12, -.40+j*.19)
    if start < 12.5:
        for k in range(math.ceil(span/.5)):
            moment = start + k*.5
            if moment < min(next_time, 12.5):
                note = root + (12 if k%4 == 3 else 0)
                add(music, bass(note, .39 if k%2 else .46), moment, .27)
    else:
        add(music, bass(root, 1.4), start, .28)

# A sparse melodic motif; delayed, panned details give the shots room to breathe.
MELODY = [
    (0.25, 77, .75), (.75, 72, .56), (1.25, 69, .50), (1.75, 72, .54),
    (2.25, 77, .72), (3.0, 76, .54), (3.5, 72, .53),
    (4.25, 74, .68), (4.75, 77, .50), (5.25, 81, .60),
    (5.75, 79, .58), (6.5, 76, .53), (7.25, 74, .53), (7.75, 72, .48),
    (8.25, 77, .70), (8.75, 81, .56), (9.25, 79, .56), (9.75, 77, .55),
    (10.75, 74, .68), (11.25, 77, .54), (11.75, 79, .54),
    (12.5, 81, .63), (12.55, 77, .50), (12.60, 72, .48)
]
for i, (when, note, velocity) in enumerate(MELODY):
    add(wet_bus, pluck(note, 2.1, velocity), when, .19, (-.29 if i%2 else .32))

# Percussion has a light opening, a confident middle, and clears for the end card.
for beat in range(25):
    when = beat*.5
    if when > 12.0:
        break
    gain = .40 if when >= 2 else .30
    if 10.0 <= when < 10.5:
        gain *= .65
    add(music, kick(), when, gain)
    if beat%2 == 1 and when >= 1.5:
        add(music, clap(), when, .30, .06)
    if when >= 1:
        add(music, hat(), when+.25, .055 if beat%2 else .075, .28)
        if when >= 4 and beat%4 in (1, 3):
            add(music, hat(), when+.375, .027, -.28)
    if beat%4 == 3 and 4 <= when < 11:
        add(music, hat(True), when+.25, .058, -.18)

# The final brand cadence gets a soft downbeat, then just the harmonic tail.
add(music, kick(), 12.5, .30)

# Stereo ambience and musical echoes, with dark diffusion rather than metallic FX.
music += wet_bus
for delay, gain, swap in [(.1875, .15, True), (.375, .13, False), (.5625, .07, True)]:
    offset = round(delay*SR)
    dark = np.column_stack([filtered(wet_bus[:,c], 4700) for c in range(2)])
    if swap:
        dark = dark[:, ::-1]
    music[offset:] += dark[:-offset]*gain
for delay, gain, swap in [(.127, .055, True), (.239, .052, False), (.347, .04, True),
                          (.421, .035, False), (.587, .029, True), (.719, .022, False),
                          (.863, .017, True), (1.071, .012, False)]:
    offset = round(delay*SR)
    dark = np.column_stack([filtered(wet_bus[:,c], 2900) for c in range(2)])
    if swap:
        dark = dark[:, ::-1]
    music[offset:] += dark[:-offset]*gain


def click(when, gain=.15, pan=0):
    t = seconds(.065)
    # Soft mechanical tick, combining filtered noise with a small wood-like body.
    x = filtered(RNG.normal(size=len(t)), [1100, 6500], "bandpass")*.24*np.exp(-t*130)
    x += .23*np.sin(2*np.pi*1250*t)*np.exp(-t*165)
    x += .15*np.sin(2*np.pi*510*t)*np.exp(-t*110)
    add(sfx, x*fades(len(t), .0008, .018), when, gain, pan)


def swish(when, duration=.42, gain=.12, direction=1):
    t = seconds(duration)
    x = RNG.normal(size=len(t))
    x = filtered(x, [500, 7800], "bandpass")
    env = np.sin(np.pi*t/duration)**2
    x *= env*.65
    # Pan through the shot, leaving the central content unobscured.
    p = np.linspace(-.65*direction, .65*direction, len(t))
    angle = (p+1)*np.pi/4
    add(sfx, np.column_stack((x*np.cos(angle), x*np.sin(angle))), when, gain)


def soft_impact(when, gain=.12):
    t = seconds(.7)
    phase = 2*np.pi*np.cumsum(57+39*np.exp(-t*12))/SR
    body = np.sin(phase)*np.exp(-t*10)
    air = filtered(RNG.normal(size=len(t)), 2100)*np.exp(-t*13)*.16
    add(sfx, (body+air)*fades(len(t), .006, .12), when, gain)


soft_impact(0, .14)
swish(.08, .42, .07)
click(.72, .26, .25)
swish(1.72, .39, .10)
click(2.23, .27, -.21)
click(3.24, .15, .18)
swish(5.19, .46, .12)
soft_impact(5.5, .11)
click(6.30, .24, .21)
click(7.78, .17, -.25)
swish(8.29, .33, .08, -1)
click(9.22, .22, -.21)
swish(10.17, .48, .12)
soft_impact(10.5, .10)
swish(12.14, .40, .09)
soft_impact(12.5, .11)
click(12.56, .18)

# Clean bus shaping. Shared gain keeps exported stems summing to the final mix.
music = np.tanh(music*1.08)/1.08
edge = fades(N, .006, .65)
music *= edge[:, None]
sfx *= edge[:, None]
combined = music+sfx
target_peak = 10**(-1.6/20)
master_gain = target_peak / np.max(np.abs(combined))
music *= master_gain
sfx *= master_gain
combined = music+sfx


def write(name, data):
    # TPDF dither before PCM16 quantization. Its level is below audible ambience.
    dither = (RNG.random(data.shape)-RNG.random(data.shape))/65536
    pcm = np.clip(np.round((data+dither)*32767), -32768, 32767).astype(np.int16)
    pcm[0] = 0
    pcm[-1] = 0
    wavfile.write(OUT/name, SR, pcm)
    return {
        "path": name, "sample_rate": SR, "channels": 2, "samples": len(data),
        "duration_seconds": len(data)/SR,
        "peak_dbfs": round(float(20*np.log10(np.max(np.abs(pcm.astype(float)))/32768)), 3),
        "rms_dbfs": round(float(20*np.log10(np.sqrt(np.mean((pcm.astype(float)/32768)**2)))), 3),
        "clipped_samples": int(np.sum(np.abs(pcm.astype(np.int32))>=32767))
    }


assets = [write("music.wav", music), write("sfx.wav", sfx), write("soundtrack.wav", combined)]
metadata = {
    "title": "Rocket Group — Forward Momentum",
    "creator": "Original procedural composition and synthesis for this project",
    "license": "CC0-1.0",
    "license_url": "https://creativecommons.org/publicdomain/zero/1.0/",
    "source_material": "All music, percussion, and sound effects synthesized by synthesize.py; no external samples",
    "bpm": 120,
    "key": "F major",
    "duration_seconds": DURATION,
    "master_peak_target_dbfs": -1.6,
    "scene_accents_seconds": [0, 2, 5.5, 10.5, 12.5],
    "arrangement": "Soft pluck and warm pad opening; restrained four-on-the-floor electronic pulse; final Fmaj7 cadence at 12.5s with natural tail and fade",
    "stem_note": "Music and SFX share master gain and sum to soundtrack apart from negligible independent quantization dither",
    "assets": assets,
    "rebuild": "python audio/synthesize.py; Python 3, numpy, scipy"
}
(OUT/"metadata.json").write_text(json.dumps(metadata, indent=2)+"\n")
print(json.dumps(metadata, indent=2))
