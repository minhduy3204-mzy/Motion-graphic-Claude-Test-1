# Rocket Group / Forward Momentum

## Style
A precise creative workspace that becomes an expressive brand film. Bold black typography, paper-white artboards and luminous flat yellow, with restrained charcoal tooling. Fine rulers and a single intentional cursor contrast with oversized typography. Direction follows the real yellow arrow in the supplied mark. Dynamic, smooth, confident, no stock space imagery.

## Evidence and limitations
Live https://rocketgroup.asia/ is blocked by the managed network proxy (CONNECT 403, 2026-10-17). No website content, screenshots, typography or services can be verified. Both requested motion-system and higgsfield-saas skills are unavailable; production uses installed HyperFrames and GSAP skills. Use the user-authorized brand-introduction fallback. No invented site or service claims.

## Palette
- #000000: exact opaque logo black (verified from supplied PNGs).
- #F0C400: exact opaque arrow yellow (verified from supplied PNGs).
- #F5F4F0: creative paper neutral; not claimed as website color.
- #161616: creative dark workspace neutral.
- #96958F: guide strokes on light; decorative only.
Text on light: #000000 or #5A5952. Text on dark: #F5F4F0 or #B8B8AE. No yellow small text on paper.

## Typography
Original wordmark.png remains unchanged. Manrope variable, weight 800, for expressive display; IBM Plex Mono 400/500 for editorial tooling. Both SIL OFL bundled from Fontsource. These are creative substitutes, not verified website fonts. Display 112–176px, UI 18–26px, URL 44–58px. Tight display tracking, tabular UI numerals.

## Motion
900 frames at 60 fps. power3/power4 entrances, expo.out precise snaps, sine.inOut gentle camera moves. Primary transition: right-to-left masked/push handoff, .5–.65s. No outgoing content fade before transition. Max 3 degrees perspective. A cursor activates frames and property values. Final lockup fully formed at 12.5s and held to 15s.

## Copy and assets
Only marketing copy: Rocket Group; Discover Rocket Group; rocketgroup.asia. UI labels are clearly motion-editor controls. Original mark.png (186x200) displayed near native size; wordmark.png (1998x340) displayed under native width. No fabricated browser page. No screenshots exist because access is blocked.

## Avoid
No fabricated business claims, literal spacecraft, unrelated colors, excessive glow, illegible microtype, distorted logos, fake website, or continuous motion on all layers.
