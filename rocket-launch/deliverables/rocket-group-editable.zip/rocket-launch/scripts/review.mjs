import puppeteer from 'puppeteer-core';
import fs from 'node:fs/promises';
const out=new URL('../review/',import.meta.url);
await fs.mkdir(out,{recursive:true});
const browser=await puppeteer.launch({executablePath:process.env.CHROME_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu']});
console.log('Review browser launched');
const page=await browser.newPage();
await page.setViewport({width:1920,height:1080,deviceScaleFactor:1});
const errors=[];
page.on('pageerror',e=>errors.push(e.message));
await page.goto('http://127.0.0.1:4173/index.html',{waitUntil:'domcontentloaded'});
console.log('Composition loaded');
await page.evaluate(async()=>{await document.fonts.ready;return true;});
console.log('Fonts ready');
const times=process.argv.slice(2).length?process.argv.slice(2).map(Number):[0,.6,1.5,2.6,3.8,4.8,5.8,7,8.9,10,11,12.5,14.983333];
for(const t of times){
  await page.evaluate(t=>{window.__timelines['rocket-launch'].time(t,false);},t);
  await page.screenshot({path:new URL(`frame-${t.toFixed(3)}.png`,out).pathname});
  console.log('Frame',t);
}
await fs.writeFile(new URL('runtime-errors.json',out),JSON.stringify(errors,null,2));
await fs.writeFile(new URL('animation-map.json',out),JSON.stringify(await page.evaluate(()=>{
  const tl=window.__timelines['rocket-launch'];
  return {labels:tl.labels,tweens:tl.getChildren(false,true,false).map(t=>({start:t.startTime(),end:t.endTime(),duration:t.duration(),ease:t.vars.ease,targets:t.targets().map(el=>el.id?'#'+el.id:el.className),properties:Object.keys(t.vars).filter(k=>!['duration','ease','parent','overwrite','immediateRender'].includes(k))}))};
}),null,2));
console.log(`Captured ${times.length} review frames; runtime errors: ${errors.length}`);
await browser.close();
if(errors.length)process.exitCode=1;
