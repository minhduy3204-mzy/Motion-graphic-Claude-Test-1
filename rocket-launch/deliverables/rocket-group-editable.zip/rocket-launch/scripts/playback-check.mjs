/* Real-time delivery playback check; run while scripts/serve.mjs is listening. */
import puppeteer from 'puppeteer-core';
import fs from 'node:fs/promises';
const browser=await puppeteer.launch({executablePath:process.env.CHROME_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--autoplay-policy=no-user-gesture-required']});
const page=await browser.newPage();
await page.setViewport({width:960,height:540});
await page.setContent('<style>body{margin:0;background:black}video{width:960px;height:540px}</style><video id="film" muted playsinline src="http://127.0.0.1:4173/renders/rocket-group-launch.mp4"></video>');
const result=await page.evaluate(async()=>{
  const video=document.querySelector('video');
  const samples=[];
  const ended=new Promise((resolve,reject)=>{
    video.addEventListener('ended',()=>resolve(true),{once:true});
    video.addEventListener('error',()=>reject(new Error(video.error?.message||'Video error')),{once:true});
    setTimeout(()=>reject(new Error('Playback exceeded 22 seconds')),22000);
  });
  const interval=setInterval(()=>samples.push({time:video.currentTime,readyState:video.readyState}),500);
  await video.play();
  await ended;
  clearInterval(interval);
  const q=video.getVideoPlaybackQuality();
  return {ended:video.ended,duration:video.duration,currentTime:video.currentTime,width:video.videoWidth,height:video.videoHeight,totalFrames:q.totalVideoFrames,droppedFrames:q.droppedVideoFrames,samples};
});
await fs.writeFile(new URL('../review/playback.json',import.meta.url),JSON.stringify(result,null,2));
console.log(JSON.stringify({...result,samples:result.samples.length},null,2));
await browser.close();
if(!result.ended||result.duration!==15||result.width!==1920||result.height!==1080)process.exitCode=1;
