# Script (music only)
0–2: original logo reveals in a design selection.
2–5.5: Discover / Rocket Group. Cursor selects the headline; yellow highlight arrives.
5.5–10.5: original logo on an editable artboard, surrounded by rulers, restrained layout controls, and a pointer. URL becomes the focal point. No fake website.
10.5–15: original wordmark, Discover Rocket Group, rocketgroup.asia. All entrances settled by 12.5. Final 2.5s stable.
